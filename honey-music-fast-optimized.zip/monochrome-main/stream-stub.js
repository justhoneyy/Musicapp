export function Stream() {}
