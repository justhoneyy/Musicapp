export class FfmpegProgress implements Honey MusicProgress {
    constructor(
        public readonly stage: 'loading' | 'parsing' | 'encoding' | 'finalizing' | 'stdout',
        public readonly progress: number,
        public readonly message?: string
    ) {}
}
