declare global {
    type Honey MusicProgress<T = object> = {
        stage: string;
    } & T;

    type Honey MusicProgressMessage<_T = Honey MusicProgress> = {
        message: string;
    };

    type Honey MusicProgressListener<T = Honey MusicProgress> = (progress: T) => void;
}

export class DownloadProgress implements Honey MusicProgress {
    public readonly stage = 'downloading';

    constructor(
        public readonly receivedBytes: number,
        public readonly totalBytes: number | undefined
    ) {}
}

export class SegmentedDownloadProgress extends DownloadProgress {
    public readonly stage = 'downloading';

    constructor(
        public readonly receivedBytes: number,
        public readonly totalBytes: number | undefined,
        public readonly currentSegment: number,
        public readonly totalSegments: number
    ) {
        super(receivedBytes, totalBytes);
    }
}

export class ProgressMessage implements Honey MusicProgressMessage {
    constructor(public readonly message: string) {}
}

export class DownloadProgressMessage extends ProgressMessage {
    constructor(message: string) {
        super(message);
    }
}
