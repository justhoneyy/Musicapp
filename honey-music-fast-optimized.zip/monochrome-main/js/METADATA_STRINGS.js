export const METADATA_STRINGS = {
    VENDOR_STRING: 'Honey Music',
    DEFAULT_TITLE: 'Unknown Title',
    DEFAULT_ARTIST: 'Unknown Artist',
    DEFAULT_ALBUM: 'Unknown Album',
};
